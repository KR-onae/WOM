web.route("/", function() {
    return {
        "response": toBuff(`HIGUY`),
        "http": 200
    };
});